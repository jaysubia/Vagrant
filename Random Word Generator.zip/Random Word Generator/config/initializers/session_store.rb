# Be sure to restart your server when you modify this file.

RandomWord::Application.config.session_store :cookie_store, key: '_random_word_session'
