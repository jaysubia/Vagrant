class DojosController < ApplicationController
  def index
  end

  def world
  end

  def ninjas
  end
end
