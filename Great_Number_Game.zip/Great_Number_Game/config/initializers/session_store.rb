# Be sure to restart your server when you modify this file.

Rails.application.config.session_store :cookie_store, key: '_Great_Number_Game_session'
